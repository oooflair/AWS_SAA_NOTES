package com.idfcfirstbank.NaturalLanguage_SQL.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.idfcfirstbank.NaturalLanguage_SQL.model.LlmDecisionResponse;

import java.util.*;

@Service
public class GroqLLMService {

    @Value("${groq.api.key:TEST_KEY}")
    private String apiKey;

    public String generateSql(String prompt) {

        try {
            RestTemplate restTemplate = new RestTemplate();

            String url = "https://api.groq.com/openai/v1/chat/completions";

            Map<String, Object> body = new HashMap<>();

            body.put("model", "llama-3.3-70b-versatile");

            List<Map<String, String>> messages = new ArrayList<>();

            Map<String, String> msg = new HashMap<>();
            msg.put("role", "user");
            msg.put("content", prompt);

            messages.add(msg);

            body.put("messages", messages);
            body.put("temperature", 0);
            body.put("max_tokens", 1200);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.setBearerAuth(apiKey);

            HttpEntity<Map<String, Object>> request =
                    new HttpEntity<>(body, headers);

            ResponseEntity<Map> response =
                    restTemplate.postForEntity(url, request, Map.class);

            Map result = response.getBody();

            List choices = (List) result.get("choices");
            Map first = (Map) choices.get(0);
            Map message = (Map) first.get("message");

            String sql = (String) message.get("content");

            return sql.trim();

        } catch (Exception e) {

            String msg = e.getMessage().toLowerCase();

            if (msg.contains("429") || msg.contains("rate limit")) {
                throw new RuntimeException("LLM_RATE_LIMIT");
            }

            throw new RuntimeException("LLM_SERVICE_ERROR");
        }
    }


    public LlmDecisionResponse analyzeQuestion(String prompt) {

        String raw = generateSql(prompt);   // reuse existing LLM call

        ObjectMapper mapper = new ObjectMapper();

        try {
            return mapper.readValue(raw, LlmDecisionResponse.class);
        } catch (Exception e) {
            throw new RuntimeException("Failed to parse LLM JSON response: " + e.getMessage());
        }
    }

}
