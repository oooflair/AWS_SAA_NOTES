package com.idfcfirstbank.NaturalLanguage_SQL.model;

public class QueryRequest {
    private String question;

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }
}
