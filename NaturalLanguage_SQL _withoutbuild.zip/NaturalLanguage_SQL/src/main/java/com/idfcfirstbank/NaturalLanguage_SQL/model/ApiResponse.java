package com.idfcfirstbank.NaturalLanguage_SQL.model;

public class ApiResponse {

    private String generatedSql;
    private QueryResponse data;

    public ApiResponse(String sql, QueryResponse data) {
        this.generatedSql = sql;
        this.data = data;
    }

    public String getGeneratedSql() {
        return generatedSql;
    }

    public QueryResponse getData() {
        return data;
    }
}
