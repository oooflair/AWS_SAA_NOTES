package com.idfcfirstbank.NaturalLanguage_SQL.controller;

import com.idfcfirstbank.NaturalLanguage_SQL.model.DailyMetric;
import com.idfcfirstbank.NaturalLanguage_SQL.service.AuditMetricsService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.Map;

@RestController
@RequestMapping("/api/audit")
public class AuditMetricsController {

    @Autowired
    private AuditMetricsService metricsService;

    // ---- Overall Stats ----
    @GetMapping("/stats")
    public Map<String, Object> overallStats() throws IOException {
        return metricsService.overallStats();
    }

    // ---- Rejection Breakdown ----
    @GetMapping("/stats/rejections")
    public Map<String, Integer> rejectionStats() throws IOException {
        return metricsService.rejectionBreakdown();
    }

    // ---- ENHANCED DAILY STATS ----
    @GetMapping("/stats/daily")
    public Map<String, DailyMetric> dailyStats() throws IOException {
        return metricsService.dailyStats();
    }

    // ---- Top Frequently Asked Questions ----
    @GetMapping("/stats/top-questions")
    public Map<String, Integer> topQuestions() throws IOException {
        return metricsService.topQuestions();
    }
}
