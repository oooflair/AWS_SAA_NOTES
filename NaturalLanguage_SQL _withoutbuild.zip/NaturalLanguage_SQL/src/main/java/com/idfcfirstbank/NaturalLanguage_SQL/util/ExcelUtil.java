package com.idfcfirstbank.NaturalLanguage_SQL.util;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.ByteArrayOutputStream;
import java.util.List;

public class ExcelUtil {

    public static byte[] createExcel(List<String> columns,
                                     List<List<Object>> rows) throws Exception {

        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Result");

        int rowNum = 0;

        Row header = sheet.createRow(rowNum++);

        for (int i = 0; i < columns.size(); i++) {
            header.createCell(i).setCellValue(columns.get(i));
        }

        for (List<Object> rowData : rows) {
            Row row = sheet.createRow(rowNum++);

            for (int i = 0; i < rowData.size(); i++) {
                Object val = rowData.get(i);
                row.createCell(i).setCellValue(val == null ? "" : val.toString());
            }
        }

        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        workbook.write(bos);
        workbook.close();

        return bos.toByteArray();
    }
}
