package com.idfcfirstbank.NaturalLanguage_SQL.validator;

import org.springframework.stereotype.Component;

import java.util.regex.Pattern;

@Component
public class IntentGuard {

    // Direct dangerous commands
    private static final Pattern DANGEROUS_PATTERN = Pattern.compile(
            "\\b(delete|drop|truncate|insert|update|alter|remove|modify|erase|vanish|wipe|clear|change data)\\b",
            Pattern.CASE_INSENSITIVE
    );

    // Safe analytical contexts where words like "created" are valid
    private static final Pattern SAFE_CONTEXT = Pattern.compile(
            "\\b(created by|created on|creation date|created user|created between|created after|created before)\\b",
            Pattern.CASE_INSENSITIVE
    );

    // Obfuscated delete patterns like: d-e-l-e-t-e, d e l e t e
    private static final Pattern OBFUSCATED_DELETE = Pattern.compile(
            "d\\s*[-_ ]\\s*e\\s*[-_ ]\\s*l\\s*[-_ ]\\s*e\\s*[-_ ]\\s*t\\s*[-_ ]\\s*e",
            Pattern.CASE_INSENSITIVE
    );

    // Obfuscated drop patterns like: d-r-o-p
    private static final Pattern OBFUSCATED_DROP = Pattern.compile(
            "d\\s*[-_ ]\\s*r\\s*[-_ ]\\s*o\\s*[-_ ]\\s*p",
            Pattern.CASE_INSENSITIVE
    );

    public boolean isAllowed(String question) {

        if (question == null || question.trim().isEmpty()) {
            return false;
        }

        String q = question.toLowerCase().trim();

        // STEP 1: If safe analytical context exists, allow
        if (SAFE_CONTEXT.matcher(q).find()) {
            return true;
        }

        // STEP 2: Normalize special characters to catch obfuscation
        String normalized = normalizeText(q);

        // STEP 3: Block obvious obfuscated attacks
        if (OBFUSCATED_DELETE.matcher(q).find() ||
                OBFUSCATED_DROP.matcher(q).find()) {
            return false;
        }

        // STEP 4: Block fuzzy dangerous words after normalization
        if (containsDangerWord(normalized)) {
            return false;
        }

        // STEP 5: Block direct dangerous commands
        if (DANGEROUS_PATTERN.matcher(q).find()) {
            return false;
        }

        return true;
    }

    private boolean containsDangerWord(String text) {

        String[] forbidden = {
                "delete",
                "drop",
                "truncate",
                "remove",
                "erase",
                "vanish",
                "wipe",
                "clear",
                "insert",
                "update",
                "modify",
                "create",
                "alter"
        };

        for (String word : forbidden) {
            if (text.contains(word)) {
                return true;
            }
        }

        return false;
    }

    private String normalizeText(String input) {

        return input
                .replace("@", "a")
                .replace("1", "i")
                .replace("!", "i")
                .replace("0", "o")
                .replace("$", "s")
                .replace("3", "e")
                .replace("5", "s")
                .replace("7", "t")
                .replace("8", "b")
                .replace("-", "")
                .replace("_", "")
                .replace(".", "")
                .replace(",", "")
                .replace("  ", " ");
    }
}
