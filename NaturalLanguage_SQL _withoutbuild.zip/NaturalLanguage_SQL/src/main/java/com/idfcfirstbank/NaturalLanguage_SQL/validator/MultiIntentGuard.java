package com.idfcfirstbank.NaturalLanguage_SQL.validator;

import org.springframework.stereotype.Component;

@Component
public class MultiIntentGuard {

    private static final String[] ANALYTICAL_KEYWORDS = {
            "show", "list", "count", "how many",
            "total", "sum", "average", "avg",
            "find", "get", "display"
    };

    public boolean isSingleIntent(String question) {

        if (question == null) return false;

        String lower = question.toLowerCase();

        int count = 0;

        for (String key : ANALYTICAL_KEYWORDS) {
            if (lower.contains(key)) {
                count++;
            }
        }

        // If more than 1 analytical intent keyword → reject
        return count <= 1;
    }
}
