package com.idfcfirstbank.NaturalLanguage_SQL.service;

import org.springframework.stereotype.Component;

@Component
public class SchemaRegistry {

    public String getSchema() {

        return """
    DATABASE SCHEMA DEFINITION:

    TABLE: customers
    - customer_id : integer (Primary Key)
    - customer_name : varchar
    - city : varchar
    - onboarded_date : date

    TABLE: orders
    - order_id : integer (Primary Key)
    - customer_id : integer (Foreign Key -> customers.customer_id)
    - amount : decimal
    - order_date : date

    TABLE: clientonboarding
    - onboarding_id : integer (Primary Key)
    - client_name : varchar
    - status : varchar
    - onboarding_date : date
    - created_by : varchar

    RELATIONSHIPS:
    customers.customer_id = orders.customer_id

    NOTES:
    - Use ONLY the tables and columns listed above.
    - Do NOT invent any new tables or columns.
    - All queries must be SELECT queries only.
    """;
    }

}
