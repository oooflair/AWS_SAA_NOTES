package com.idfcfirstbank.NaturalLanguage_SQL.exception;

import com.idfcfirstbank.NaturalLanguage_SQL.model.ErrorResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@ControllerAdvice
public class GlobalExceptionHandler {

    // --------------------------------------------------
    // 1. Business Validation Rejections
    // --------------------------------------------------
    @ExceptionHandler(QueryRejectedException.class)
    public ResponseEntity<ErrorResponse> handleRejected(QueryRejectedException ex) {

        ErrorResponse response = new ErrorResponse(
                ex.getFriendlyMessage(),
                ex.getRejectedBy()
        );

        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
    }

    // --------------------------------------------------
    // 2. Runtime Exceptions (LLM / Service Level Errors)
    // --------------------------------------------------
    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<ErrorResponse> handleRuntime(RuntimeException ex) {

        String message = ex.getMessage();

        // ---- Handle LLM Rate Limit Gracefully ----
        if ("LLM_RATE_LIMIT".equals(message)) {

            ErrorResponse response = new ErrorResponse(
                    "Service temporarily busy",
                    "Application",
                    "AI service is currently under heavy load. Please try again after some time or contact API Support Team."
            );

            return new ResponseEntity<>(response, HttpStatus.TOO_MANY_REQUESTS);
        }

        // ---- Handle Generic LLM Failure ----
        if ("LLM_SERVICE_ERROR".equals(message)) {

            ErrorResponse response = new ErrorResponse(
                    "AI processing unavailable",
                    "Application",
                    "Unable to process your request at the moment. Please contact API Support Team."
            );

            return new ResponseEntity<>(response, HttpStatus.SERVICE_UNAVAILABLE);
        }

        // ---- Default Runtime Exception ----
        ErrorResponse response = new ErrorResponse(
                "Application error occurred",
                "Application",
                "Unexpected processing error. Please contact API Support Team."
        );

        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
    }

    // --------------------------------------------------
    // 3. Catch All Unhandled Exceptions
    // --------------------------------------------------
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleGeneric(Exception ex) {

        ErrorResponse response = new ErrorResponse(
                "Something went wrong",
                "System",
                "Internal system error occurred. Please contact support."
        );

        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
