package com.idfcfirstbank.NaturalLanguage_SQL.service;

import com.idfcfirstbank.NaturalLanguage_SQL.model.DailyMetric;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class AuditMetricsService {

    @Value("${audit.file.path:logs/audit-log.txt}")
    private String auditFile;

    private List<String> readLines() throws IOException {
        if (!Files.exists(Paths.get(auditFile))) {
            return List.of();
        }
        return Files.readAllLines(Paths.get(auditFile));
    }

    // ---- Overall Stats ----
    public Map<String, Object> overallStats() throws IOException {

        List<String> lines = readLines();

        int totalRequests = 0;
        int success = 0;
        int rejected = 0;

        for (String line : lines) {
            if (line.contains("REQUEST:")) totalRequests++;
            if (line.contains("SUCCESS")) success++;
            if (line.contains("REJECTED BY")) rejected++;
        }

        Map<String, Object> stats = new HashMap<>();
        stats.put("totalRequests", totalRequests);
        stats.put("successful", success);
        stats.put("rejected", rejected);

        return stats;
    }

    // ---- Rejection Breakdown ----
    public Map<String, Integer> rejectionBreakdown() throws IOException {

        List<String> lines = readLines();

        Map<String, Integer> breakdown = new HashMap<>();

        for (String line : lines) {
            if (line.contains("REJECTED BY")) {

                String rejectedBy = line.split("REJECTED BY:")[1]
                        .split("\\|")[0]
                        .trim();

                breakdown.put(
                        rejectedBy,
                        breakdown.getOrDefault(rejectedBy, 0) + 1
                );
            }
        }

        return breakdown;
    }

    // ---- ENHANCED DAILY STATS (Success + Failure + Guards) ----
    public Map<String, DailyMetric> dailyStats() throws IOException {

        List<String> lines = readLines();

        Map<String, DailyMetric> daily = new HashMap<>();

        String currentDate = null;

        for (String line : lines) {

            if (line.startsWith("[")) {
                currentDate = line.substring(1, 11);
            }

            if (currentDate == null) continue;

            DailyMetric metric =
                    daily.computeIfAbsent(currentDate, k -> new DailyMetric());

            if (line.contains("REQUEST:")) {
                metric.incrementTotal();
            }

            if (line.contains("SUCCESS")) {
                metric.incrementSuccess();
            }

            if (line.contains("REJECTED BY")) {

                String guard = line.split("REJECTED BY:")[1]
                        .split("\\|")[0]
                        .trim();

                metric.incrementRejected(guard);
            }
        }

        return daily;
    }

    // ---- Top Frequently Asked Questions ----
    public Map<String, Integer> topQuestions() throws IOException {

        List<String> lines = readLines();

        Map<String, Integer> freq = new HashMap<>();

        for (String line : lines) {

            if (line.contains("REQUEST:")) {

                String question = line.split("REQUEST:")[1].trim();

                freq.put(question, freq.getOrDefault(question, 0) + 1);
            }
        }

        return freq.entrySet()
                .stream()
                .sorted((a, b) -> b.getValue() - a.getValue())
                .limit(10)
                .collect(
                        java.util.stream.Collectors.toMap(
                                Map.Entry::getKey,
                                Map.Entry::getValue,
                                (e1, e2) -> e1,
                                java.util.LinkedHashMap::new
                        )
                );
    }
}
