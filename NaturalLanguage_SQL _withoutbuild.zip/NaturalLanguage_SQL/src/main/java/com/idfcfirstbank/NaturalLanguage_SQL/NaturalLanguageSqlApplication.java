package com.idfcfirstbank.NaturalLanguage_SQL;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NaturalLanguageSqlApplication {

    public static void main(String[] args) {
        SpringApplication.run(NaturalLanguageSqlApplication.class, args);
    }

}
