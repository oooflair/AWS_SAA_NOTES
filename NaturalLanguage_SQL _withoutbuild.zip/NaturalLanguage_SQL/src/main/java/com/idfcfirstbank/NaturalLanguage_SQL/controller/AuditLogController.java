package com.idfcfirstbank.NaturalLanguage_SQL.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

@RestController
@RequestMapping("/api/audit")
public class AuditLogController {

    @Value("${audit.file.path:logs/audit-log.txt}")
    private String auditFile;

    // 1️⃣ View logs in browser / postman
    @GetMapping("/view")
    public ResponseEntity<String> viewLogs() throws IOException {

        File file = new File(auditFile);

        if (!file.exists()) {
            return ResponseEntity.ok("No audit logs available yet.");
        }

        String content = new String(Files.readAllBytes(Paths.get(auditFile)));

        return ResponseEntity.ok()
                .contentType(MediaType.TEXT_PLAIN)
                .body(content);
    }

    // 2️⃣ Download logs as file
    @GetMapping("/download")
    public ResponseEntity<FileSystemResource> downloadLogs() {

        File file = new File(auditFile);

        if (!file.exists()) {
            return ResponseEntity.notFound().build();
        }

        FileSystemResource resource = new FileSystemResource(file);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=audit-log.txt")
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .body(resource);
    }
}
