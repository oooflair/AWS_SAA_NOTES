package com.idfcfirstbank.NaturalLanguage_SQL.service;

import com.idfcfirstbank.NaturalLanguage_SQL.db.DatabaseService;
import com.idfcfirstbank.NaturalLanguage_SQL.model.LlmDecisionResponse;
import com.idfcfirstbank.NaturalLanguage_SQL.model.QueryResponse;
import com.idfcfirstbank.NaturalLanguage_SQL.validator.SqlValidator;
import com.idfcfirstbank.NaturalLanguage_SQL.validator.IntentGuard;
import com.idfcfirstbank.NaturalLanguage_SQL.exception.QueryRejectedException;
import com.idfcfirstbank.NaturalLanguage_SQL.validator.MultiIntentGuard;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class QueryService {

    @Autowired
    private SqlValidator validator;

    @Autowired
    private DatabaseService databaseService;

    @Autowired
    private SchemaRegistry schemaRegistry;

    @Autowired
    private UnifiedPromptBuilder promptBuilder;

    @Autowired
    private GroqLLMService llmService;

    @Autowired
    private LogService logService;

    @Autowired
    private IntentGuard intentGuard;

    @Autowired
    private QueryLimiter queryLimiter;

    @Autowired
    private AuditFileService auditService;

    @Autowired
    private MultiIntentGuard multiIntentGuard;

    public QueryResponse process(String question) {

        auditService.logRequest(question);
        logService.log("Processing new request: " + question);

        // ---- BASIC VALIDATION ----
        if (question == null || question.trim().isEmpty()) {
            auditService.logRejection(question, "InputValidation");

            throw new QueryRejectedException(
                    "Question cannot be empty.",
                    "InputValidation"
            );
        }

        question = question.trim();

        // ---- MULTI INTENT CHECK ----
        if (!multiIntentGuard.isSingleIntent(question)) {
            auditService.logRejection(question, "MultiIntentGuard");

            throw new QueryRejectedException(
                    "Multiple intents detected.",
                    "MultiIntentGuard",
                    "Please ask only ONE business question at a time."
            );
        }

        // ---- KEYWORD BASED GUARD ----
        if (!intentGuard.isAllowed(question)) {
            auditService.logRejection(question, "IntentGuard");

            throw new QueryRejectedException(
                    "Unsafe operation detected.",
                    "IntentGuard",
                    "I can only answer read-only analytical questions."
            );
        }

        // ---- BUILD UNIFIED PROMPT ----
        String schema = schemaRegistry.getSchema();
        String prompt = promptBuilder.build(schema, question);

        // ---- SINGLE LLM CALL ----
        LlmDecisionResponse decision = llmService.analyzeQuestion(prompt);

        if (!decision.isAllowed()) {
            auditService.logRejection(question, "IntentClassifier");

            throw new QueryRejectedException(
                    decision.getReason(),
                    "IntentClassifier",
                    decision.getExplanation()
            );
        }

        String sql = decision.getSql();

        auditService.logSql(sql);
        logService.log("LLM Generated SQL: " + sql);

        if (sql == null || sql.trim().isEmpty()) {
            auditService.logRejection(question, "SchemaConstraint");

            throw new QueryRejectedException(
                    "Question cannot be answered using available schema.",
                    "SchemaConstraint"
            );
        }

        sql = sql.trim();

        // ---- MULTI SQL PROTECTION ----
        if (sql.contains(";") && sql.split(";").length > 1) {
            auditService.logRejection(question, "MultiSqlGuard");

            throw new QueryRejectedException(
                    "Multiple SQL statements detected.",
                    "MultiSqlGuard",
                    "Only ONE SQL statement allowed."
            );
        }

        // ---- TECHNICAL SAFETY CHECK ----
        if (!validator.isSafe(sql)) {
            auditService.logRejection(question, "SqlValidator");

            throw new QueryRejectedException(
                    "Potentially unsafe query.",
                    "SqlValidator"
            );
        }

        // ---- ENFORCE LIMIT ----
        String limitedSql = queryLimiter.enforceLimit(sql);

        QueryResponse response = databaseService.execute(limitedSql);

        if (response == null) {
            response = new QueryResponse();
        }

        if (response.getRows() == null) {
            response.setRows(new ArrayList<>());
        }

        if (response.getColumns() == null) {
            response.setColumns(new ArrayList<>());
        }

        int rowCount = response.getRows().size();

        if (rowCount == 0) {
            response.setNote("No records found matching your query.");
        }

        if (rowCount >= queryLimiter.getMaxRows()) {
            response.setNote("Result limited to " + queryLimiter.getMaxRows() + " rows.");
        }

        auditService.logSuccess(question, rowCount);

        return response;
    }
}
