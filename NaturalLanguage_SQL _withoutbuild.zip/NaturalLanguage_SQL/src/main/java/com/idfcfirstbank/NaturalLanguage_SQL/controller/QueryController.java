package com.idfcfirstbank.NaturalLanguage_SQL.controller;

import com.idfcfirstbank.NaturalLanguage_SQL.service.QueryService;
import com.idfcfirstbank.NaturalLanguage_SQL.model.QueryRequest;
import com.idfcfirstbank.NaturalLanguage_SQL.model.QueryResponse;
import com.idfcfirstbank.NaturalLanguage_SQL.model.ApiResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import org.springframework.http.*;
import com.idfcfirstbank.NaturalLanguage_SQL.util.ExcelUtil;


@RestController
@RequestMapping("/api")
public class QueryController {

    @Autowired
    private QueryService queryService;

    @PostMapping("/query")
    public ApiResponse ask(@RequestBody QueryRequest request) {

        QueryResponse response = queryService.process(request.getQuestion());

        return new ApiResponse("SQL Shown in Logs", response);
    }


    @PostMapping("/query/download")
    public ResponseEntity<byte[]> download(@RequestBody QueryRequest request) throws Exception {

        QueryResponse response = queryService.process(request.getQuestion());

        byte[] excel = ExcelUtil.createExcel(
                response.getColumns(),
                response.getRows()
        );

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.setContentDispositionFormData("attachment", "result.xlsx");

        return ResponseEntity.ok()
                .headers(headers)
                .body(excel);
    }

}
