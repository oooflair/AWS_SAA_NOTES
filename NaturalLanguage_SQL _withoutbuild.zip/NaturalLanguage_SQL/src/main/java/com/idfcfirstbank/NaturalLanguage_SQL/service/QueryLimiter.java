package com.idfcfirstbank.NaturalLanguage_SQL.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class QueryLimiter {

    @Value("${query.max.rows:5000}")
    private int maxRows;


    public String enforceLimit(String sql) {

        if (sql == null || sql.trim().isEmpty()) {
            return sql;
        }

        String lower = sql.toLowerCase();

        // If query already has limit, respect it
        if (lower.contains("limit")) {
            return sql;
        }

        // Append safe limit for PGSQL
            return sql + " LIMIT " + maxRows;
        // Append safe limit for Oracle
            //return sql + " FETCH FIRST " + maxRows + " ROWS ONLY";

    }

    public int getMaxRows() {
        return maxRows;
    }
}
