package com.idfcfirstbank.NaturalLanguage_SQL.model;

public class ErrorResponse {

    private String error;
    private String rejectedBy;
    private String details;

    public ErrorResponse(String error, String rejectedBy) {
        this.error = error;
        this.rejectedBy = rejectedBy;
        this.details = "";
    }

    public ErrorResponse(String error, String rejectedBy, String details) {
        this.error = error;
        this.rejectedBy = rejectedBy;
        this.details = details;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public String getRejectedBy() {
        return rejectedBy;
    }

    public void setRejectedBy(String rejectedBy) {
        this.rejectedBy = rejectedBy;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }
}
