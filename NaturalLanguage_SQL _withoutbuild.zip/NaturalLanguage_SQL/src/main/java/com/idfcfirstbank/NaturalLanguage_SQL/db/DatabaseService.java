package com.idfcfirstbank.NaturalLanguage_SQL.db;

import com.idfcfirstbank.NaturalLanguage_SQL.model.QueryResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class DatabaseService {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public QueryResponse execute(String sql) {

        QueryResponse response = new QueryResponse();

        List<String> columns = new ArrayList<>();
        List<List<Object>> rows = new ArrayList<>();

        try {
            List<Map<String, Object>> result =
                    jdbcTemplate.queryForList(sql);

            if (!result.isEmpty()) {

                Map<String, Object> firstRow = result.get(0);

                // Set column names
                columns.addAll(firstRow.keySet());

                // Set row data
                for (Map<String, Object> map : result) {
                    List<Object> row = new ArrayList<>();
                    for (String col : columns) {
                        row.add(map.get(col));
                    }
                    rows.add(row);
                }
            }

            response.setColumns(columns);
            response.setRows(rows);

        } catch (Exception e) {

            // Even on exception return empty lists
            response.setColumns(new ArrayList<>());
            response.setRows(new ArrayList<>());
            response.setNote("Error while executing query: " + e.getMessage());
        }

        return response;
    }

}
