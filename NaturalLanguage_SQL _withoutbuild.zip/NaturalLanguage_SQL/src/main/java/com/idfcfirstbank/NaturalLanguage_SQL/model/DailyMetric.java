package com.idfcfirstbank.NaturalLanguage_SQL.model;

import java.util.HashMap;
import java.util.Map;

public class DailyMetric {

    private int total = 0;
    private int success = 0;
    private int rejected = 0;

    private Map<String, Integer> rejectedBy = new HashMap<>();

    public void incrementTotal() {
        total++;
    }

    public void incrementSuccess() {
        success++;
    }

    public void incrementRejected(String guard) {
        rejected++;

        rejectedBy.put(
                guard,
                rejectedBy.getOrDefault(guard, 0) + 1
        );
    }

    public int getTotal() { return total; }
    public int getSuccess() { return success; }
    public int getRejected() { return rejected; }
    public Map<String, Integer> getRejectedBy() { return rejectedBy; }
}
