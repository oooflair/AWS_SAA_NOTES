package com.idfcfirstbank.NaturalLanguage_SQL.validator;

import org.springframework.stereotype.Component;

@Component
public class SqlValidator {

    public boolean isSafe(String sql) {

        if (sql == null) return false;

        String lower = sql.toLowerCase().trim();

        // Only allow SELECT
        if (!lower.startsWith("select")) {
            return false;
        }

        // No multiple statements
        if (sql.split(";").length > 1) {
            return false;
        }

        // Block dangerous keywords
        String[] banned = {
                "insert ", "update ", "delete ",
                "drop ", "truncate ", "alter ",
                "create ", "grant ", "revoke "
        };

        for (String b : banned) {
            if (lower.contains(b)) {
                return false;
            }
        }

        return true;
    }
}
