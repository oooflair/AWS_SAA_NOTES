package com.idfcfirstbank.NaturalLanguage_SQL.exception;

public class QueryRejectedException extends RuntimeException {

    private String rejectedBy;
    private String friendlyMessage;

    public QueryRejectedException(String message, String rejectedBy) {
        super(message);
        this.rejectedBy = rejectedBy;
        this.friendlyMessage = message;
    }

    public QueryRejectedException(String message, String rejectedBy, String friendlyMessage) {
        super(message);
        this.rejectedBy = rejectedBy;
        this.friendlyMessage = friendlyMessage;
    }

    public String getRejectedBy() {
        return rejectedBy;
    }

    public String getFriendlyMessage() {
        return friendlyMessage;
    }
}
