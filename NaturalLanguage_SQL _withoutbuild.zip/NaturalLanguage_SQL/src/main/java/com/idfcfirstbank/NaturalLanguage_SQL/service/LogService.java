package com.idfcfirstbank.NaturalLanguage_SQL.service;

import org.springframework.stereotype.Service;

@Service
public class LogService {

    public void log(String message) {
        System.out.println("[AI-QUERY] " + message);
    }
}
