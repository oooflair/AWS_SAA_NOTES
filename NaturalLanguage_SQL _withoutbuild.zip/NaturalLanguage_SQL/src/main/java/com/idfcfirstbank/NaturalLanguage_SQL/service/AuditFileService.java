package com.idfcfirstbank.NaturalLanguage_SQL.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Service
public class AuditFileService {

    @Value("${audit.file.path:logs/audit-log.txt}")
    private String auditFile;

    private final DateTimeFormatter formatter =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private synchronized void writeLine(String text) {
        try {
            File file = new File(auditFile);

            // Create parent directories if they don’t exist
            File parent = file.getParentFile();
            if (parent != null && !parent.exists()) {
                parent.mkdirs();
            }

            FileWriter writer = new FileWriter(file, true);
            writer.write(text + "\n");
            writer.close();

        } catch (IOException e) {
            System.out.println("Failed to write audit log: " + e.getMessage());
        }
    }

    public void logRequest(String question) {

        if (question == null || question.trim().isEmpty()) {
            question = "EMPTY_REQUEST";
        }

        String log = String.format(
                "[%s] REQUEST: %s",
                LocalDateTime.now().format(formatter),
                question
        );
        writeLine(log);
    }


    public void logRejection(String question, String rejectedBy) {
        String log = String.format(
                "[%s] REJECTED BY: %s | QUESTION: %s",
                LocalDateTime.now().format(formatter),
                rejectedBy,
                question
        );
        writeLine(log);
    }

    public void logSql(String sql) {
        String log = String.format(
                "[%s] GENERATED SQL: %s",
                LocalDateTime.now().format(formatter),
                sql
        );
        writeLine(log);
    }

    public void logSuccess(String question, int rows) {
        String log = String.format(
                "[%s] SUCCESS | ROWS: %d | QUESTION: %s",
                LocalDateTime.now().format(formatter),
                rows,
                question
        );
        writeLine(log);
    }

    // -------------- ADD THIS NEW METHOD ----------------

    public String readLogs() {

        try {
            Path path = Paths.get(auditFile);

            if (!Files.exists(path)) {
                return "No audit logs generated yet.";
            }

            return Files.readString(path);

        } catch (Exception e) {
            return "Unable to read logs: " + e.getMessage();
        }
    }
}
